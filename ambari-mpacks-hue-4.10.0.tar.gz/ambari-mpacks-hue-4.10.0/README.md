# ambari-hue-mpack
<h1>Hue Management Pack for Ambari.</h1>

Install Hue with Ambari using this management pack created by Acceldata for ODP clusters.

| Component(s)  | Component Version | ODP Stack Version | Binary URL |
|---------------|-------------------|-------------------|------------|
| Apache Ambari | 2.7.6.x           | 3.2.2.0-2         |            |
| Apache Hue | 4.10.0          | 3.2.2.0-2         |            |

#### Version Key
- hue-4.10.0.3.2.2.0-2.tar.gz  - Hue-4.10.0 mpack, compatible with ODP 3.2.2.0-2 release.

#### Usage Notes
- Minimal install requires Ambari, HDFS, Hive, Tez, Yarn, & Zookeeper
# Before installing make below changes if the cluster has spark installed.
1. Login into the Hue node, where you need to install:
   Edit /var/lib/ambari-agent/cache/common-services/HUE/4.10.0/package/scripts/params.py
   comment line 358 and below line
````
#spark_thriftserver_hosts = config[‘clusterHostInfo’][‘spark2_thriftserver_hosts’]
spark_thriftserver_hosts = “localhost”
````
# Installation
Steps to Install Ambari Hue Mpack:
1. Download branch from code and zip with tar.gz extension
2. Upload gzipped file to ambari-server
3. Execute below command for installation
```
ambari-server install-mpack --mpack=hue-4.10.0.3.2.2.0-2.tar.gz --verbose
ambari-server restart
```
4. Login to Ambari UI and go to Add Hue service
5. Select hosts for Hue Server components
6. Start all stopped or required services

## Hue Custom Database
1. Get Database details.
2. Create the hue database and configure the hue user (with your own password):
# Example Using Hue with MySQL:
1. Create a new user in MySQL
2. grant privileges to it to manage the database using the MySQL database admin utility:
```
mysql -u root -p
create database hue ;
CREATE USER $HUEUSER IDENTIFIED BY '$HUEPASSWORD';
GRANT ALL PRIVILEGES on *.* to '$HUEUSER'@'localhost' WITH GRANT OPTION;
GRANT ALL on $HUEUSER.* to '$HUEUSER'@'localhost' IDENTIFIED BY $HUEPASSWORD;
grant all on $HUEUSER'.* to '$HUEUSER''@'%' identified by '$HUEPASSWORD';
FLUSH PRIVILEGES;
```
where $HUEUSER is the Hue user name and $HUEPASSWORD is the Hue user password.

# Uninstallation
Steps to Uninstall Ambari Hue Mpack:
1. Login to Ambari service and goto Hue section
2. Stop Hue service and delete permanently
3. Execute below command for uninstallation
```
ambari-server uninstall-mpack --mpack-name=hue-ambari.mpack
ambari-server restart
```

# Troubleshooting Steps for known issues

**Problem 1** : There is a current bug in User Group Management for Ambari 2.7 & ODP 3.x.

**workaround**
is the following python command before installing Hue
```python
/var/lib/ambari-server/resources/scripts/configs.py -u admin -p admin -n [CLUSTER_NAME] -l [CLUSTER_FQDN] -t 8080 -a set -c cluster-env -k  ignore_groupsusers_create -v true
```
**** be sure to get the correct [CLUSTER_NAME] and [CLUSTER_FQDN] for command above
