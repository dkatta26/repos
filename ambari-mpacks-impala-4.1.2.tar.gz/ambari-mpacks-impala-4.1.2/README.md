# ambari-impala-mpack
This repo contains impala mpack for Ambari.

| Component(s)  | Component Version | ODP Stack Version | Binary URL |
|---------------|-------------------|-------------------|------------|
| Apache Ambari | 2.7.6.x           | 3.2.2.0-1         |            |
| Apache Impala | 4.1.2          | 3.2.2.0-1         |            |

# Installation
Steps to Install Ambari Impala Mpack:
1. Download branch from code and zip with tar.gz extension
2. Upload gzipped file to ambari-server
3. Execute below command for installation
```
ambari-server install-mpack --mpack=ambari-impala-mpack.tar.gz -v
ambari-server restart
```
4. Login to Ambari UI and go to Add Impala service
5. Select hosts from Catalog & Statestore components
6. Select daemons from given host list and proceed for service deployment to complete installation
7. Start all stopped or required services

# Uninstallation
Steps to Uninstall Ambari Impala Mpack:
1. Login to Ambari service and goto Impala section
2. Stop Impala service and delete permanently
3. Execute below command for uninstallation
```
ambari-server uninstall-mpack --mpack=ambari-impala-mpack -v
ambari-server restart
```

# Troubleshooting Steps

**Problem 1** : Ranger Auth Enablement

ranger-hive-security.xml not present in all daemons except on hive servers causing start failure and if audit is enabled then this file ranger-hive-audit.xml is also unavailable

```
F0214 14:55:06.908636 40022 frontend.cc:148] InternalException: Unable to instantiate authorization provider: org.apache.impala.authorization.ranger.RangerAuthorizationFactory
CAUSED BY: InvocationTargetException: null
CAUSED BY: IllegalArgumentException: bound must be positive
. Impalad exiting.
```

**Workaround**

Copy ranger-hive-security xml and ranger-hive-audit.xml from hive-servers under /etc/hive/conf/ as enabled with Ranger

**Problem 2** : Solr Audit Enablement

If solr is enabled on ranger audit then daemons will not start on infra-solr-clients as underlying impala-solr libraries symlink are broke

**Workaround**

need ambari-infra-solr installation on all daemons for resolving solr symlinks

**Problem 3** : Ranger cache policies missing during  

Also missing cache policies on other launched daemons or impala components
```
2023-02-06T10:19:21,074 ERROR [main] org.apache.ranger.plugin.contextenricher.RangerTagEnricher$RangerTagRefresher - failed to save service-tags to cache file '/etc/ranger/adodp_hive/policycache/impala_adodp_hive_tag.json'
java.io.FileNotFoundException: /etc/ranger/adodp_hive/policycache/impala_adodp_hive_tag.json (No such file or directory)
at java.io.FileOutputStream.open0(Native Method) ~[?:1.8.0_342]
at java.io.FileOutputStream.open(FileOutputStream.java:270) ~[?:1.8.0_342]
```

**Workaround**

Need ranger policy cache directories under /etc/ranger/conf and copy policy cache files with respective policy dir
