# -*- coding: utf-8 -*-
from resource_management import *
import os


class ImpalaBase(Script):
    impala_packages = [
        'impala-server',
        'impala-catalog',
        'impala-state-store',
        'impala-shell']
    # Call setup.sh to install the service

    def installImpala(self, env):
        # Install packages listed in metainfo.xml
        self.install_packages(env)
        if self.impala_packages is not None and len(self.impala_packages):
            for pack in self.impala_packages:
                Package(pack)
        import params
        env.set_params(params)

        scriptDir = params.files_dir
        #libnativeTaska = None
        #libnativeTaskso = None
        #libZstdso = None
        #for lib in os.listdir(scriptDir):
        #   if lib.startswith('libnativetask') and lib.endswith(".a"):
        #        libnativeTaska = lib
        #File(
        #    "/usr/lib/impala/lib/"+libnativeTaska,
        #    content=StaticFile(os.path.join(scriptDir,libnativeTaska)), mode=0o644)
        #    if lib.startswith('libnativetask.so') and lib.endswith(".0"):
        #        libnativeTaskso = lib
        #File(
        #    "/usr/lib/impala/lib/"+libnativeTaskso,
        #    content=StaticFile(os.path.join(scriptDir,libnativeTaskso)), mode=0o644)
        #    if lib.startswith('libzstd.so') and lib.endswith(".0"):
        #        libZstdso = lib
        #File(
        #    "/usr/lib/impala/lib/"+libZstdso,
        #    content=StaticFile(os.path.join(scriptDir,libZstdso)), mode=0o644)
        # init lib
        File(format("{tmp_dir}/impala_init_lib.sh"),
             content=Template('init_lib.sh.j2'), mode=0o700)
          #   content=Template('init_lib.sh.j2',libnativeTaskso=libnativeTaskso), mode=0o700)
           #  content=Template('init_lib.sh.j2',libZstdso=libZstdso), mode=0o700)
        Execute(format("bash {tmp_dir}/impala_init_lib.sh"))
        File("/etc/default/bigtop-utils",
             content="export JAVA_HOME=/usr/lib/jvm/java-1.8.0-openjdk")

    def configureImpala(self, env):
        import params
        env.set_params(params)
        # if params.security_enabled:
        #     cmd = format("{service_packagedir}/scripts/ktuntil_config.sh")
        #     Execute('echo "Running ' + cmd + '" as root')
        #     Execute(cmd, ignore_failures=True)
        realm_name = os.popen(
            'grep "default_realm" /etc/krb5.conf ').read().strip(os.linesep).split(' ')[-1]
        File("/etc/default/impala",
             content=Template("impala.j2", realm_name=realm_name),
             mode=0o644
             )

        #create log4j.properties in conf dir
        File(os.path.join(params.scp_conf_dir, "log4j.properties"),
             owner=params.impala_user,
             group=params.impala_group,
             content=InlineTemplate(params.impala_log4j_properties),
             mode=0o644
             )
        for directory in format("{impala_scratch_dir}").split(","):
            Directory(format(directory), mode=0o777)
        self.configureHDFS(env)

        # Add hive-site.xml on node if not present
        if not os.path.exists(os.path.join(params.scp_conf_dir,'hive-site.xml')) :
            XmlConfig("hive-site.xml",
              conf_dir = params.scp_conf_dir,
              configurations = params.hive_site_config,
              configuration_attributes = params.config['configurationAttributes']['hive-site'],
              owner = params.impala_user,
              group = params.impala_group,
              mode = 0o644)

        # Add hive-ranger confs to impala_conf_dir on enabling ranger
        if params.enable_ranger :
            XmlConfig(format('ranger-hive-audit.xml'),
                      conf_dir=params.scp_conf_dir,
                      configurations=params.config['configurations']['ranger-hive-audit'],
                      configuration_attributes=params.config['configurationAttributes']['ranger-hive-audit'],
                      owner = params.impala_user,
                      group = params.impala_group,
                      mode=0o744)
            XmlConfig(format('ranger-hive-security.xml'),
                      conf_dir=params.scp_conf_dir,
                      configurations=params.config['configurations']['ranger-hive-security'],
                      configuration_attributes=params.config['configurationAttributes']['ranger-hive-security'],
                      owner = params.impala_user,
                      group = params.impala_group,
                      mode=0o744)
            XmlConfig(format('ranger-policymgr-ssl.xml'),
                      conf_dir=params.scp_conf_dir,
                      configurations=params.config['configurations']['ranger-hive-policymgr-ssl'],
                      configuration_attributes=params.config['configurationAttributes']['ranger-hive-policymgr-ssl'],
                      owner = params.impala_user,
                      group = params.impala_group,
                      mode=0o744)

    def configureHDFS(self, env):
        import params
        for service_name in params.scp_conf_from.keys():
            for fndir in params.scp_conf_from[service_name]["files"]:
                fn = os.path.split(fndir)[-1]
                if os.path.exists(fndir) :
                    Execute(
                        format(
                            "scp -r %s {tmp_dir}" %
                            (fndir)))
                    File(format("{scp_conf_dir}/%s" % fn),
                         content=StaticFile(format("{tmp_dir}/%s" % fn)),
                         mode=0o644,
                         encoding="utf-8")
