# ambari-nifi-mpack
<h1>Nifi Management Pack for Ambari.</h1>

Install Nifi with Ambari using this management pack created by Acceldata for ODP clusters.

| Component(s)         | Component Version |
|----------------------|-------------------|
| Apache Ambari        | 2.7.6.x           | 
| Apache Nifi          | 1.23.2            |
| Apache Nifi-Registry | 1.23.2            |

#### Version Key
-  nifi-1.23.2.tar.gz  - Nifi-1.23.2 mpack

#### Usage Notes
- Minimal install requires Ambari, HDFS & Zookeeper

# Installation
Steps to Install Ambari Nifi Mpack:
1. Download branch from code and zip with tar.gz extension
2. Upload gzipped file to ambari-server
3. Execute below command for installation
```
ambari-server install-mpack --mpack=nifi-1.23.2.tar.gz --verbose
ambari-server restart
```
4. Login to Ambari UI and go to Add Nifi service
5. Select hosts for Nifi components
6. Start all stopped or required services

# Uninstallation
Steps to Uninstall Ambari Nifi Mpack:
1. Login to Ambari service and goto Nifi section
2. Stop Nifi service and delete permanently
3. Execute below command for uninstallation
```
ambari-server uninstall-mpack --mpack-name=nifi-ambari-mpack
ambari-server restart
```

# Troubleshooting Steps for known issues

**Problem 1** : There is a current bug in User Group Management for Ambari 2.7 & ODP 3.x.

**workaround**
is the following python command before installing Nifi
```python
/var/lib/ambari-server/resources/scripts/configs.py -u admin -p admin -n [CLUSTER_NAME] -l [CLUSTER_FQDN] -t 8080 -a set -c cluster-env -k  ignore_groupsusers_create -v true
```
**** be sure to get the correct [CLUSTER_NAME] and [CLUSTER_FQDN] for command above