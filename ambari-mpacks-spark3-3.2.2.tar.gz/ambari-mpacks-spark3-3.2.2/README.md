# ambari-impala-mpack
<h1>Spark3 Management Pack for Ambari.</h1>

Install Spark3 with Ambari using this management pack created by Acceldata.

| Component(s)  | Component Version | ODP Stack Version | Binary URL |
|---------------|-------------------|-------------------|------------|
| Apache Ambari | 2.7.6.x           | 3.2.2.0-2         |            |
| Apache Spark | 3.2.2          | 3.2.2.0-2         |            |

#### Version Key
- spark3_mpack-3.2.2.tar.gz  - Spark3.2.2 mpack, compatible with ODP 3.2.2.0-2 release.

#### Usage Notes
- Minimal install requires Ambari, HDFS, Hive, Tez, Yarn, & Zookeeper

# Installation
Steps to Install Ambari Spark3 Mpack:
1. Download branch from code and zip with tar.gz extension
2. Upload gzipped file to ambari-server
3. Execute below command for installation
```
ambari-server install-mpack --mpack=spark3_mpack-3.2.2.tar.gz --verbose
```

In case user finds below errors run below commands as mentioned:
```
    (mpack_metadata, mpack_name, mpack_version, mpack_staging_dir, mpack_archive_path) = _install_mpack(options, replay_mode)
  File "/usr/lib/ambari-server/lib/ambari_server/setupMpacks.py", line 798, in _install_mpack
    process_stack_addon_service_definitions_artifact(artifact, artifact_source_dir, options)
  File "/usr/lib/ambari-server/lib/ambari_server/setupMpacks.py", line 557, in process_stack_addon_service_definitions_artifact
    sudo.symlink(source_service_version_path, dest_link)
  File "/usr/lib/ambari-server/lib/resource_management/core/sudo.py", line 130, in symlink
    os.symlink(source, link_name)
OSError: [Errno 17] File exists

ambari-server uninstall-mpack --mpack-name=spark3-ambari-3.2.2.mpack

rm -rf /var/lib/ambari-server/data/tmp/ambari-mpacks-spark3-3.2.2*/ /var/lib/ambari-server/resources/stacks/ODP/3.0/services/SPARK3 /var/lib/ambari-server/resources/stacks/ODP/3.1/services/SPARK3 /var/lib/ambari-server/resources/common-services/SPARK3 /var/lib/ambari-agent/cache/stacks/ODP/3.0/services/SPARK3 /var/lib/ambari-agent/cache/stacks/ODP/3.1/services/SPARK3 /var/lib/ambari-agent/cache/common-services/SPARK3 /var/lib/ambari-agent/cache/stacks/ODP/3.2/services/SPARK3
```

Run the installation command again in case of above failures :
```
ambari-server install-mpack --mpack=spark3_mpack-3.2.2.tar.gz --verbose

cd /var/lib/ambari-server/resources/stacks/ODP/3.0/services/
rm -f SPARK3
ln -s /var/lib/ambari-server/resources/mpacks/spark3-ambari-3.2.2.mpack-3.2.2/common-services/SPARK3/3.2.2 SPARK3
cd ../../3.1/services/
rm -f SPARK3
ln -s /var/lib/ambari-server/resources/mpacks/spark3-ambari-3.2.2.mpack-3.2.2/common-services/SPARK3/3.2.2 SPARK3
ambari-server restart
```
After running above commands you will see this message
```
INFO: Management pack spark3-ambari-3.2.2.mpack-3.2.2 successfully installed! Please restart ambari-server.
INFO: Loading properties from /etc/ambari-server/conf/ambari.properties
Ambari Server 'install-mpack' completed successfully.
```

4. Login to Ambari UI and go to Add Spark3 service
5. Select hosts for Spark thrift and client components
6. Start all stopped or required services

# Uninstallation
Steps to Uninstall Ambari Spark3 Mpack:
1. Login to Ambari service and goto Spark3 section
2. Stop Spark service and delete permanently
3. Execute below command for uninstallation
```
ambari-server uninstall-mpack --mpack-name=spark3-ambari-3.2.2.mpack
ambari-server restart
```

# Troubleshooting Steps

**Problem 1** : There is a current bug in User Group Management for Ambari 2.7 & ODP 3.x.

**workaround** 
is the following python command before installing Spark3
```python
/var/lib/ambari-server/resources/scripts/configs.py -u admin -p admin -n [CLUSTER_NAME] -l [CLUSTER_FQDN] -t 8080 -a set -c cluster-env -k  ignore_groupsusers_create -v true
```
**** be sure to get the correct [CLUSTER_NAME] and [CLUSTER_FQDN] for command above