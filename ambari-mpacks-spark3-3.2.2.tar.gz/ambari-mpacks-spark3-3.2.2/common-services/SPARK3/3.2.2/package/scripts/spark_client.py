#!/usr/bin/python
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

"""

import sys
from resource_management.libraries.script.script import Script
from resource_management.libraries.functions import stack_select
from resource_management.libraries.functions.stack_features import check_stack_feature
from resource_management.libraries.functions.constants import StackFeature
from resource_management.core.exceptions import ClientComponentHasNoStatus
from resource_management.core.logger import Logger
from resource_management.core import shell
from resource_management.core.resources import File
from resource_management.core.resources.system import Execute
from resource_management.core.source import Template
from resource_management.libraries.functions.format import format
from setup_spark import setup_spark

class SparkClient(Script):
  def install(self, env):
    self.install_packages(env)
    self.configure(env)

  def configure(self, env, upgrade_type=None, config_dir=None):
    import params,os
    env.set_params(params)
    file_path = os.path.dirname(os.path.realpath(__file__)).replace('scripts','templates')+'/init_spark_client_link.sh.j2'
    dir_path = '/usr/odp/'+params.stack_version+'/spark3/'
    params.substitute_jinja(file_path,dir_path)
    File(format("{tmp_dir}/init_spark_client_link.sh"),
         content=Template('init_spark_client_link.sh.j2'), mode=0o700)
    Execute(format("bash {tmp_dir}/init_spark_client_link.sh"))
    
    setup_spark(env, 'client', upgrade_type=upgrade_type, action = 'config')

  def status(self, env):
    raise ClientComponentHasNoStatus()
  
  def pre_upgrade_restart(self, env, upgrade_type=None):
    import params

    env.set_params(params)
    if params.version and check_stack_feature(StackFeature.ROLLING_UPGRADE, params.version):
      Logger.info("Executing Spark3 Client Stack Upgrade pre-restart")
      stack_select.select_packages(params.version)

if __name__ == "__main__":
  SparkClient().execute()

