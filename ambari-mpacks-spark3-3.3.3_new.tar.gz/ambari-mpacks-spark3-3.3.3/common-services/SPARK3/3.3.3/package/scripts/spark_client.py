#!/usr/bin/python
"""
Licensed to the Apache Software Foundation (ASF) under one
or more contributor license agreements.  See the NOTICE file
distributed with this work for additional information
regarding copyright ownership.  The ASF licenses this file
to you under the Apache License, Version 2.0 (the
"License"); you may not use this file except in compliance
with the License.  You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.

"""

import sys, os, pwd, grp, signal, time, glob, socket
from resource_management.libraries.script.script import Script
from resource_management.libraries.functions import stack_select
from resource_management.libraries.functions import conf_select
from resource_management.libraries.functions.stack_features import check_stack_feature
from resource_management.libraries.functions.constants import StackFeature
from resource_management.core.exceptions import ClientComponentHasNoStatus
from resource_management.core.logger import Logger
from resource_management.core import shell
from resource_management.core.resources import File
from resource_management.core.resources.system import Execute
from resource_management.core.source import Template
from resource_management.libraries.functions.format import format
from setup_spark import setup_spark
from resource_management import *
from resource_management.core import sudo

class SparkClient(Script):
  def install(self, env):
    self.install_packages(env)
    self.create_30_config_version(env)
    self.configure(env)

  def configure(self, env, upgrade_type=None, config_dir=None):
    import params,os
    env.set_params(params)
    file_path = os.path.dirname(os.path.realpath(__file__)).replace('scripts','templates')+'/init_spark_client_link.sh.j2'
    dir_path = '/usr/odp/'+params.stack_version+'/spark3/'
    params.substitute_jinja(file_path,dir_path)
    File(format("{tmp_dir}/init_spark_client_link.sh"),
         content=Template('init_spark_client_link.sh.j2'), mode=0o700)
    Execute(format("bash {tmp_dir}/init_spark_client_link.sh"))
    setup_spark(env, 'client', upgrade_type=upgrade_type, action = 'config')

  def status(self, env):
    raise ClientComponentHasNoStatus()
  
  def pre_upgrade_restart(self, env, upgrade_type=None):
    import params

    env.set_params(params)
    if params.version and check_stack_feature(StackFeature.ROLLING_UPGRADE, params.version):
      Logger.info("Executing Spark3 Client Stack Upgrade pre-restart")
      stack_select.select_packages(params.version)


  def create_30_config_version(self, env):
    import params,os
    package_name = 'spark3'
    stack_root = Script.get_stack_root()
    current_dir = "{0}/current/spark3/conf".format(stack_root)
    directories = [{"conf_dir": "/etc/spark3/conf","current_dir": current_dir}]
    stack_version = params.stack_version
    conf_dir = "/etc/spark3/conf"
    if stack_version:
      try:
        #Check if broken symbolic links issue exists
        os.stat(conf_dir)
        conf_select.convert_conf_directories_to_symlinks(package_name, stack_version, directories)
        sudo.unlink(conf_dir)
        ln_cmd = as_sudo(["ln","-s","-f","/usr/odp/current/spark3-client/conf","/etc/spark3/conf"])
        Execute(ln_cmd,logoutput = True)
        cp_cmd = as_sudo(["cp","-a","-f","/etc/spark3/conf.backup/.","/etc/spark3/conf"])
        Execute(cp_cmd,logoutput = True)
      except OSError as e:
        Logger.warning("Detected broken symlink : {0}. Attempting to repair.".format(str(e)))
        #removing symlink conf directory
        sudo.unlink(conf_dir)
        #make conf dir again
        sudo.makedirs(conf_dir,0o755)
        #copy all files
        for files in glob.glob("/etc/spark3/conf.backup/*"):
          cp_cmd = as_sudo(["cp","-r",files,conf_dir])
          Execute(cp_cmd,logoutput = True)
        conf_select.convert_conf_directories_to_symlinks(package_name, stack_version, directories)

if __name__ == "__main__":
  SparkClient().execute()

